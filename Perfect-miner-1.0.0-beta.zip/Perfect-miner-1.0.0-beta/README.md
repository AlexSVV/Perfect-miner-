# Perfect-miner
Perfect miner(alog: yescrypt r16)
